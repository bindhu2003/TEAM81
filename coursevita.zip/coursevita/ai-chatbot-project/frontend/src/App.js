import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css'; // Optional: For custom styling

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch previous chat history from the server
    const fetchHistory = async () => {
      try {
        const response = await axios.get('http://localhost:5000/chat-history');
        setMessages(response.data);
      } catch (error) {
        console.error('Error fetching chat history:', error);
        setError('Could not fetch chat history.');
      }
    };
    fetchHistory();
  }, []);

  const sendMessage = async () => {
    if (input.trim()) {
      try {
        const response = await axios.post('http://localhost:5000/chat', {
          message: input,
        });
        const botReply = response.data.reply;

        // Update messages state
        setMessages([...messages, { userMessage: input, botResponse: botReply }]);
        setInput(''); // Clear the input field
        setError(''); // Clear any previous error messages
      } catch (error) {
        console.error('Error sending message:', error);
        setError('Failed to send message. Please try again.');
      }
    } else {
      setError('Input cannot be empty.');
    }
  };

  return (
    <div className="chat-container">
      <h1>Chatbot</h1>
      {error && <p className="error">{error}</p>}
      <div className="chat-window">
        {messages.map((msg, index) => (
          <div key={index}>
            <p><strong>You:</strong> {msg.userMessage}</p>
            <p><strong>Bot:</strong> {msg.botResponse}</p>
          </div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask me something..."
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default App;
