// Chat.js
import React, { useState } from 'react';
import axios from 'axios';

const Chat = () => {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);

  const sendMessage = async () => {
    if (!message) return;

    // Add user message to chat history
    const newChatHistory = [...chatHistory, { userMessage: message, botResponse: '' }];
    setChatHistory(newChatHistory);

    try {
      const response = await axios.post('http://localhost:5000/chat', { message });
      const botReply = response.data.reply;

      // Update the chat history with bot response
      const updatedChatHistory = newChatHistory.map((chat, index) => {
        if (index === newChatHistory.length - 1) {
          return { ...chat, botResponse: botReply };
        }
        return chat;
      });

      setChatHistory(updatedChatHistory);
      setMessage(''); // Clear the input field
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  return (
    <div>
      <h2>Chat with AI</h2>
      <div style={{ maxHeight: '400px', overflowY: 'scroll', border: '1px solid #ccc', padding: '10px' }}>
        {chatHistory.map((chat, index) => (
          <div key={index}>
            <strong>You:</strong> {chat.userMessage}<br />
            <strong>Bot:</strong> {chat.botResponse}
            <hr />
          </div>
        ))}
      </div>
      <input 
        type="text" 
        value={message} 
        onChange={(e) => setMessage(e.target.value)} 
        placeholder="Type your message..." 
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
};

export default Chat;
