// Import required modules
const http = require('http');
const url = require('url');
const { GoogleGenerativeAI } = require("@google/generative-ai");

// Initialize the Google Generative AI client with your API key
const genAI = new GoogleGenerativeAI("AIzaSyAraGd5cIeR4Kr_6Owcn7nmUiEiFX1pJtg");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Set the server port and chat history array
const port = 5001;
const chatHistory = [];

// Create the HTTP server
const server = http.createServer((req, res) => {
  // Parse the incoming request URL
  const parsedUrl = url.parse(req.url, true);

  // Allow CORS (Cross-Origin Resource Sharing)
  res.setHeader('Access-Control-Allow-Origin', '*'); // Allow all origins
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); // Allow specific methods
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type'); // Allow content-type header

  // Handle OPTIONS request for CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204); // No content
    return res.end();
  }

  // Handle GET request for chat history
  if (parsedUrl.pathname === '/chat-history' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(chatHistory));

  // Handle POST request for sending a message
  } else if (parsedUrl.pathname === '/chat' && req.method === 'POST') {
    let body = '';

    // Gather data from the request
    req.on('data', chunk => {
      body += chunk.toString(); // Convert Buffer to string
    });

    req.on('end', async () => {
      try {
        const { message } = JSON.parse(body); // Parse the JSON message

        // Generate a response using Gemini AI
        const prompt = message; // Use the user's message as the prompt
        const result = await model.generateContent(prompt);
        const botResponse = result.response.text(); // Get the generated text

        // Store user message and bot response in chat history
        chatHistory.push({ userMessage: message, botResponse });

        // Send the response back
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ reply: botResponse }));
      } catch (error) {
        console.error('Error processing message:', error); // Log the error for debugging
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Failed to process message' }));
      }
    });

  } else {
    // Handle 404 Not Found
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('404 Not Found');
  }
});

// Start the server
server.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
